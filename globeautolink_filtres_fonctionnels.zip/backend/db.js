
const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'globeautolink',
    port: 3306,
    multipleStatements: true
});

db.connect(err => {
    if (err) {
        console.error('Erreur de connexion à MySQL :', err);
    } else {
        console.log('Connexion MySQL réussie depuis db.js');
    }
});

module.exports = db;
