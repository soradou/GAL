// Données de voitures supprimées — maintenant chargées dynamiquement depuis la base
