
document.addEventListener('DOMContentLoaded', () => {
    // Charger dynamiquement les options de filtre depuis l'API
    fetch('/api/options')
        .then(res => res.json())
        .then(data => {
            populateSelect('search-brand', data.brands);
            populateSelect('search-model', data.models);
            populateSelect('search-year', data.years);
            populateSelect('search-energy', data.energy);
            populateSelect('search-gearbox', data.gearbox);
        });

    function populateSelect(id, options) {
        const select = document.getElementById(id);
        if (!select) return;
        options.forEach(opt => {
            const option = document.createElement('option');
            option.value = opt;
            option.textContent = opt;
            select.appendChild(option);
        });
    }

    // Déclenche le filtrage à chaque modification
    const inputs = document.querySelectorAll('#search-brand, #search-model, #search-year, #search-energy, #search-gearbox, #search-minPrice, #search-maxPrice');
    inputs.forEach(input => input.addEventListener('change', fetchFilteredCars));

    function fetchFilteredCars() {
        const brand = document.getElementById('search-brand').value;
        const model = document.getElementById('search-model').value;
        const year = document.getElementById('search-year').value;
        const energy = document.getElementById('search-energy').value;
        const gearbox = document.getElementById('search-gearbox').value;
        const minPrice = document.getElementById('search-minPrice').value;
        const maxPrice = document.getElementById('search-maxPrice').value;

        let url = `/api/cars?`;
        if (brand) url += `brand=${encodeURIComponent(brand)}&`;
        if (model) url += `model=${encodeURIComponent(model)}&`;
        if (year) url += `year=${encodeURIComponent(year)}&`;
        if (energy) url += `energy=${encodeURIComponent(energy)}&`;
        if (gearbox) url += `gearbox=${encodeURIComponent(gearbox)}&`;
        if (minPrice) url += `minPrice=${encodeURIComponent(minPrice)}&`;
        if (maxPrice) url += `maxPrice=${encodeURIComponent(maxPrice)}&`;

        fetch(url)
            .then(res => res.json())
            .then(cars => {
                const container = document.getElementById('cars-list');
                container.innerHTML = cars.map(car => `
                    <div class="car-card">
                        <h3>${car.carBrand} ${car.carModel} (${car.year})</h3>
                        <p>Prix: ${car.price} DA</p>
                        <p>Kilométrage: ${car.currentMiles} km</p>
                        <p>Carburant: ${car.energy}</p>
                        <p>Boîte: ${car.gearbox}</p>
                    </div>
                `).join('');
            });
    }
});
