const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

// Connect to MySQL -----------------------------------------------------------------------------------------
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', 
    database: 'globeautolink',
    port: 3306 
});

db.connect(err => {
    if (err) {
        console.error('Database connection failed:', err);
    } else {
        console.log('Connected to MySQL');
    }
});
// end MySQL connection  ------------------------------------------------------------------------------------

exports.signup = (req, res) => {
    console.log(req.body);

    const { name, email, password, passwordConfirm } = req.body;

    db.query('SELECT email FROM users WHERE email = ?', [email], async (err, results) => {
        if (err) {
            console.log(err);
        }
        if (results.length > 0) {
            return res.render("signup", { 
                message: "That email is already in use" });
        }
        else if (password !== passwordConfirm) {
            return res.render("signup", { 
                message: "Passwords do not match" });
        }

        let hashedPassword = await bcrypt.hash(password, 8);
        console.log(hashedPassword);
    })

    
}