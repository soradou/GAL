const express = require('express');
const router = express.Router();
const db = require('../db'); // Connexion MySQL

router.get('/cars', (req, res) => {
    const { brand, model, minPrice, maxPrice, year, energy } = req.query;

    let query = "SELECT * FROM carads WHERE is_available = 1";
    let params = [];

    if (brand) {
        query += " AND carBrand = ?";
        params.push(brand);
    }
    if (model) {
        query += " AND carModel = ?";
        params.push(model);
    }
    if (minPrice) {
        query += " AND price >= ?";
        params.push(minPrice);
    }
    if (maxPrice) {
        query += " AND price <= ?";
        params.push(maxPrice);
    }
    if (year) {
        query += " AND year = ?";
        params.push(year);
    }
    if (energy) {
        query += " AND energy = ?";
        params.push(energy);
    }

    db.query(query, params, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});


router.get('/options', (req, res) => {
    const query = `
        SELECT DISTINCT carBrand FROM carads WHERE is_available = 1;
        SELECT DISTINCT carModel FROM carads WHERE is_available = 1;
        SELECT DISTINCT year FROM carads WHERE is_available = 1;
        SELECT DISTINCT energy FROM carads WHERE is_available = 1;
        SELECT DISTINCT gearbox FROM carads WHERE is_available = 1;
    `;

    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({
            brands: results[0].map(r => r.carBrand),
            models: results[1].map(r => r.carModel),
            years: results[2].map(r => r.year),
            energy: results[3].map(r => r.energy),
            gearbox: results[4].map(r => r.gearbox),
        });
    });
});


module.exports = router;

router.get('/options', (req, res) => {
    const query = `
        SELECT DISTINCT carBrand FROM carads WHERE is_available = 1;
        SELECT DISTINCT carModel FROM carads WHERE is_available = 1;
        SELECT DISTINCT year FROM carads WHERE is_available = 1;
        SELECT DISTINCT energy FROM carads WHERE is_available = 1;
        SELECT DISTINCT gearbox FROM carads WHERE is_available = 1;
    `;
    db.query(query, [1], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({
            brands: results[0].map(r => r.carBrand),
            models: results[1].map(r => r.carModel),
            years: results[2].map(r => r.year),
            energy: results[3].map(r => r.energy),
            gearbox: results[4].map(r => r.gearbox),
        });
    });
});