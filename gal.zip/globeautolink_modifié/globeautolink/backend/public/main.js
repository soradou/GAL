function toggleFilter() {
    const sidebar = document.querySelector('.filter-sidebar');
    sidebar.classList.toggle('active');
}

// Menu burger
document.addEventListener("DOMContentLoaded", function () {
    const menuIcon = document.getElementById("menu-icon");
    const navbar = document.getElementById("navbar");

    menuIcon.addEventListener("click", function () {
        navbar.classList.toggle("active");
    });

    // 🔍 Bouton de recherche qui ouvre le filtre rapide
    const searchIcon = document.getElementById("search-icon");
    const quickSearchBox = document.getElementById("quick-search");

    searchIcon.addEventListener("click", function () {
        if (quickSearchBox) {
            quickSearchBox.classList.toggle("active");
        }
    });
});
