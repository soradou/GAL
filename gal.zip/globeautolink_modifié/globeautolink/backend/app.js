const express = require('express');
const app = express();
const path = require('path');
const mysql = require('mysql2/promise');
const exphbs = require('express-handlebars');

// Configuration Handlebars
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));
app.engine('hbs', exphbs.engine({ extname: 'hbs', defaultLayout: false }));

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Connexion MySQL
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'globeautolink'
});

// Rendre la BDD accessible dans les routes
app.use((req, res, next) => {
    req.db = db;
    next();
});

// Page d'accueil avec affichage voitures
app.get('/', async (req, res) => {
    try {
        const [brandsRows] = await db.query("SELECT DISTINCT carBrand FROM carads");
        const [modelsRows] = await db.query("SELECT DISTINCT carModel FROM carads");
        const [fuelTypesRows] = await db.query("SELECT DISTINCT energy FROM carads");
        const [transmissionRows] = await db.query("SELECT DISTINCT gearbox FROM carads");
        const [categoriesRows] = await db.query("SELECT DISTINCT carType FROM carads");
        const [cars] = await db.query("SELECT * FROM carads LIMIT 6");

        res.render('index', {
            brands: brandsRows.map(r => r.carBrand),
            models: modelsRows.map(r => r.carModel),
            fuelTypes: fuelTypesRows.map(r => r.energy),
            transmissions: transmissionRows.map(r => r.gearbox),
            categories: categoriesRows.map(r => r.carType),
            cars
        });
    } catch (err) {
        console.error(err);
        res.status(500).send("Erreur serveur");
    }
});

// Route de recherche
app.get('/search', async (req, res) => {
    const {
        carBrand,
        carModel,
        minPrice,
        maxPrice,
        minYear,
        maxYear,
        fuelType,
        transmission,
        category,
        maxMileage
    } = req.query;

    let sql = "SELECT * FROM carads WHERE 1=1";
    const params = [];

    if (carBrand) { sql += " AND carBrand = ?"; params.push(carBrand); }
    if (carModel) { sql += " AND carModel = ?"; params.push(carModel); }
    if (fuelType) { sql += " AND energy = ?"; params.push(fuelType); }
    if (transmission) { sql += " AND gearbox = ?"; params.push(transmission); }
    if (category) { sql += " AND carType = ?"; params.push(category); }
    if (minPrice) { sql += " AND price >= ?"; params.push(minPrice); }
    if (maxPrice) { sql += " AND price <= ?"; params.push(maxPrice); }
    if (minYear) { sql += " AND year >= ?"; params.push(minYear); }
    if (maxYear) { sql += " AND year <= ?"; params.push(maxYear); }
    if (maxMileage) { sql += " AND currentMiles <= ?"; params.push(maxMileage); }

    const [cars] = await db.query(sql, params);
    const [brandsRows] = await db.query("SELECT DISTINCT carBrand FROM carads");
    const [modelsRows] = await db.query("SELECT DISTINCT carModel FROM carads");
    const [fuelTypesRows] = await db.query("SELECT DISTINCT energy FROM carads");
    const [transmissionRows] = await db.query("SELECT DISTINCT gearbox FROM carads");
    const [categoriesRows] = await db.query("SELECT DISTINCT carType FROM carads");

    res.render('index', {
        brands: brandsRows.map(r => r.carBrand),
        models: modelsRows.map(r => r.carModel),
        fuelTypes: fuelTypesRows.map(r => r.energy),
        transmissions: transmissionRows.map(r => r.gearbox),
        categories: categoriesRows.map(r => r.carType),
        cars
    });
});

// Authentification
app.use('/', require('./routes/pages'));
app.use('/auth', require('./routes/auth'));

// Serveur
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`✅ Serveur lancé : http://localhost:${PORT}`);
});
