const express = require('express')
const authController = require('../controllers/auth')
const router = express.Router()

// routes 

router.post("/signup", authController.signup)

// end routes
module.exports = router