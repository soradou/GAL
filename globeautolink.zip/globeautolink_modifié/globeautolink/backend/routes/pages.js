const express = require('express')
const router = express.Router()

// routes 

router.get("/index", (req, res) => {
    res.render("index.hbs");
});
router.get("/signup", (req, res) => {
    res.render("signup.hbs");
});
router.get("/login", (req, res) => {
    res.render("login.hbs");
});

// end routes
module.exports = router